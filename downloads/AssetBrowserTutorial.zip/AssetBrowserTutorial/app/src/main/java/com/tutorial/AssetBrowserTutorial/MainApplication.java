package com.tutorial.AssetBrowserTutorial;

import android.app.Application;

import com.adobe.creativesdk.foundation.AdobeCSDKFoundation;
import com.adobe.creativesdk.foundation.auth.IAdobeAuthClientCredentials;

/**
 * Created by oliverbelanger on 6/19/15.
 */
public class MainApplication extends Application implements IAdobeAuthClientCredentials {

    private static final String CREATIVE_SDK_SAMPLE_CLIENT_ID = "89b22c54ea2e4915b4c0398f7f16dcd1";
    private static final String CREATIVE_SDK_SAMPLE_CLIENT_SECRET = "72dbde3c-348a-417b-9993-2b72304c2087";

    @Override
    public void onCreate(){
        super .onCreate();
        AdobeCSDKFoundation.initializeCSDKFoundation((getApplicationContext()));
    }

    @Override
    public String getClientID() {
        return CREATIVE_SDK_SAMPLE_CLIENT_ID;
    }

    @Override
    public String getClientSecret() {
        return CREATIVE_SDK_SAMPLE_CLIENT_SECRET;
    }
}
