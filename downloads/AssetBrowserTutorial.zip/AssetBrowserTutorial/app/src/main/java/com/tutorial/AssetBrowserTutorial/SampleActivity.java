package com.tutorial.AssetBrowserTutorial;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.adobe.creativesdk.foundation.auth.AdobeAuthException;
import com.adobe.creativesdk.foundation.auth.AdobeAuthSessionHelper;
import com.adobe.creativesdk.foundation.auth.AdobeAuthSessionLauncher;
import com.adobe.creativesdk.foundation.auth.AdobeUXAuthManager;
import com.adobe.creativesdk.foundation.storage.AdobeAsset;
import com.adobe.creativesdk.foundation.storage.AdobeAssetException;
import com.adobe.creativesdk.foundation.storage.AdobeAssetFile;
import com.adobe.creativesdk.foundation.storage.AdobeAssetFileRenditionType;
import com.adobe.creativesdk.foundation.storage.AdobeAssetImageDimensions;
import com.adobe.creativesdk.foundation.storage.AdobeSelection;
import com.adobe.creativesdk.foundation.storage.AdobeSelectionAsset;
import com.adobe.creativesdk.foundation.storage.AdobeUXAssetBrowser;
import com.adobe.creativesdk.foundation.storage.AdobeUXAssetBrowserConfiguration;
import com.adobe.creativesdk.foundation.storage.AdobeUXAssetBrowserOption;
import com.adobe.creativesdk.foundation.storage.IAdobeGenericRequestCallback;
import com.tutorial.AssetBrowserTutorial.R;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.EnumSet;

//activity declaration
public class SampleActivity extends Activity {

    //activity global space, we set global variables here
    private static int DEFAULT_SIGN_IN_REQUEST_CODE = 2002;
    private final AdobeUXAuthManager _uxAuthManager = AdobeUXAuthManager.getSharedAuthManager();
    private AdobeAuthSessionHelper _authSessionHelper = null;

    //control minimal UI
    private ImageView imageView;
    private Button button;

    //tracks login status
    private boolean signFlag;

    //constant request code for Asset Browser activity
    private final int CREATIVE_SDK_SAMPLE_REQUEST_CODE = 100;

    //Session helper to check the login status
    private AdobeAuthSessionHelper.IAdobeAuthStatusCallback _statusCallback = new AdobeAuthSessionHelper.IAdobeAuthStatusCallback() {
        @Override
        public void call(AdobeAuthSessionHelper.AdobeAuthStatus status, AdobeAuthException exception) {
            if (AdobeAuthSessionHelper.AdobeAuthStatus.AdobeAuthLoggedIn == status) {
                signFlag = true;
                //change the text in the button
                button.setText("Open Access Browser");

            } else {
                signFlag = false;
            }
        }
    };


    /*
    private AdobeAuthSessionHelper.IAdobeAuthStatusCallback _statusCallback = new AdobeAuthSessionHelper.IAdobeAuthStatusCallback() {

        @Override
        public void call(AdobeAuthSessionHelper.AdobeAuthStatus status, AdobeAuthException exception) {
            if (AdobeAuthSessionHelper.AdobeAuthStatus.AdobeAuthLoggedIn == status) {

                //Assumptions getting started
                signFlag = true;
                button.setText("Open Access Browser");

            } else {
                //assumptions getting started
                signFlag = false;
            }
        }
    };
*/

    //function that calls the login logic
    public void showNotLoggedInUI(){
        _uxAuthManager.login(new AdobeAuthSessionLauncher.Builder().withActivity(this).withRequestCode(DEFAULT_SIGN_IN_REQUEST_CODE).build());
        button.setText("Open Access Browser");

    }

    //onCreate function that is called when the activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //call the init() function to launch the UI
        init();

        //assumptions getting started
        _authSessionHelper = new AdobeAuthSessionHelper(_statusCallback);
        _authSessionHelper.onCreate(savedInstanceState);


    }

    //assumptions getting started
    @Override
    protected void onResume() {
        super.onResume();
        _authSessionHelper.onResume();
    }

    //assumptions getting started
    @Override
    protected void onPause() {
        super.onPause();
        _authSessionHelper.onPause();
    }

    //assumptions getting started
    @Override
    protected void onStart() {
        super.onStart();
        _authSessionHelper.onStart();
    }

    //assumptions getting started
    @Override
    protected void onStop() {
        super.onStop();
        _authSessionHelper.onStop();
    }

    //assumptions getting started
    @Override
    protected void onDestroy() {
        super.onDestroy();
        _authSessionHelper.onDestroy();
    }

    //when the activity receives the result from another activity it executes this function
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        _authSessionHelper.onActivityResult(requestCode, resultCode, data);

        //execute if a file from the Asset Browser was selected
        if (requestCode == CREATIVE_SDK_SAMPLE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {

            //instatiates the ResultProvider helper class method
            AdobeUXAssetBrowser.ResultProvider assetBrowserResult = new AdobeUXAssetBrowser.ResultProvider(data);

            //creates a new ArrayList of AdobeSelection objects that is filled in by the ArrayList of AdobeSelection objects returned by the getSelectionAssetArray() method of the instantiated ResultProvider
            ArrayList<AdobeSelection> mSelectedAssetsList = assetBrowserResult.getSelectionAssetArray();

            //grab the first AdobeSelection object from the ArrayList
            AdobeSelection selectionObj = mSelectedAssetsList.get(0);

            //check to make sure that the selected object is an AdobeSelectionAsset, then retrieve it and pass it to our convert function
            if (selectionObj instanceof AdobeSelectionAsset)
                convertToImage(((AdobeSelectionAsset) selectionObj).getSelectedItem(), imageView);
        }

        //execute if no file was selected and the back button was pressed
        else if(requestCode == CREATIVE_SDK_SAMPLE_REQUEST_CODE && resultCode == RESULT_CANCELED){
            //do nothing
        }
    }

    //function to set up the view of our activity
    private void init() {
        setContentView(R.layout.activity_sample);
        button = (Button) findViewById(R.id.button);
        imageView = (ImageView)  findViewById(R.id.imageView);

        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!signFlag) {
                    showNotLoggedInUI();
                } else {
                    //call the gotoAssetBrowserScreen if the user is logged in.
                    gotoAssetBrowserScreen();
                }
            }
        });
    }

    //function to launch the Asset Browser
    private void gotoAssetBrowserScreen() {

        //Displays a Creative Cloud asset browser component for viewing and selecting Adobe Creative Cloud assets.
        //This API pops up the default File Browser as an Activity

        //retrieves an instance of the AdobeUXAssetBrowser activity using the Creative Cloud SDK.
        AdobeUXAssetBrowser sharedAssetBrowserInstance = AdobeUXAssetBrowser.getSharedInstance();

        //creates the AssetBrowser configuration object to add options to
        AdobeUXAssetBrowserConfiguration browserConfiguration = new AdobeUXAssetBrowserConfiguration();

        //adds an enum of options constants to the options property of AssetBrowser configuration object, in this case ENABLE_MYACCOUNT_OPTION which will enable My Account
        browserConfiguration.options = EnumSet.of(AdobeUXAssetBrowserOption.ENABLE_MYACCOUNT_OPTION);

        //launches the AdobeUXAssetBrowser singleton with customized options, in this case enabling My Account
        sharedAssetBrowserInstance.popupFileBrowser(this, CREATIVE_SDK_SAMPLE_REQUEST_CODE, browserConfiguration);
    }

    //method that converts the passed AdobeAsset into an image and sets the passed imageView to that image
    private void convertToImage(AdobeAsset asset, final ImageView localImageView) {
        if (asset instanceof AdobeAssetFile) {
            final AdobeAssetFile aFile = (AdobeAssetFile) asset;
            Log.d("AtachImage","Calling AtachImage>>>>>>>>>>>>>>>>>>>>>>>");
            aFile.getRenditionWithType(AdobeAssetFileRenditionType.ADOBE_ASSET_FILE_RENDITION_TYPE_PNG,
                    //set the dimensions of the image to those of the passed imageview
                    new AdobeAssetImageDimensions(localImageView.getWidth() , localImageView.getHeight()),

                    //if everything succesfull then the AdobeAsset is converted to an image and the image view is set to that image
                    new IAdobeGenericRequestCallback<byte[], AdobeAssetException>() {
                        @Override
                        public void onCompletion(byte[] data) {
                            InputStream inData = new ByteArrayInputStream(data);
                            Bitmap image = BitmapFactory.decodeStream(inData);
                            localImageView.setImageBitmap(image);
                            Log.d("AtachImage", "COMPLETED getRenditionWithType>>>>>>>>>>>>>>>>>>>>>>>");
                        }

                        @Override
                        public void onCancellation() {
                            //do nothing
                        }

                        //if there is an error then we change the image view to have a red background and an error is logged.
                        @Override
                        public void onError(AdobeAssetException error) {
                            localImageView.setBackgroundColor(Color.parseColor("#ffff251c"));
                            Log.d("ERROR", "ERROR getRenditionWithType>>>>>>>>>>>>>>>>>>>>>>>");
                        }

                        @Override
                        public void onProgress(double progress) {
                            //do nothing
                        }
                    });
        }
    }


}